"""Art modules."""
from .art import *
__version__ = ART_VERSION
